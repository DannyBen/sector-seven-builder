-------------------------------
File Blender in other languages
-------------------------------

Replace your File Blender.ini file with one of the files in this folder in 
order to run File Blender in this language.

If you wish to translate File Blender to another language, simply modify the 
strings section in the File Blender.ini file.

If you wish to contribute your translation file for the use of others, please 
send it to db@sector-seven.net and it will be included in the next release.

The lang folder is not used by File Blender and may be deleted if not needed.

-------------------------------

Translation files were kindly provided by these individuals:

* French translation file by Louis Parmentier.
* Russian translation file by Ivan Laktionov.
* German translation file by Wolfram Wagner.
* Italian translation file by Fabrizio Conti.
* Swedish translation file by �ke Engelbrektson.
* Turkish translation file by Ismail Tuzun.
* Spanish translation file by Marcelo Camacho Moreno.
* Dutch translation file by Rens Klaverstijn.
* Polish translation file by Marek Bogacz.
* Greek translation file by geogeo.gr.
