================================================================================

    ControlPad
    A Numeric Pad Control Engine
        
    Danny Ben Shitrit (Sector-Seven) 2009
    db@sector-seven.net
        
================================================================================

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
  OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE 
  USE OR OTHER DEALINGS IN THE SOFTWARE.
  
================================================================================

  ControlPad Homepage:
  http://sector-seven.net/software/controlpad

================================================================================

  If this is the first time you are running ControlPad, you may want to:
  � Right click the ControlPad system tray icon for some options
  � Press and hold the * key on your numeric keypad to get started.
  � Refer to the help file
  
================================================================================
  
  